import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

function isolatedRuntimeRoot(source, fallback, expectedPort){
  if(String(process.env.HF_DASHBOARD_PORT||expectedPort)!==String(expectedPort))throw new Error("INSTANCE_PORT_MISMATCH");
  const base=fs.realpathSync(source),candidate=path.resolve(process.env.HF_DASHBOARD_ROOT||fallback);
  const relative=path.relative(base,candidate);
  if(relative===".."||relative.startsWith(".."+path.sep)||path.isAbsolute(relative))throw new Error("INSTANCE_ROOT_MISMATCH");
  let current=candidate;
  while(true){
    if(fs.existsSync(current)&&fs.lstatSync(current).isSymbolicLink())throw new Error("INSTANCE_ROOT_REPARSE_POINT");
    const parent=path.dirname(current);if(parent===current)break;current=parent;
  }
  return candidate;
}


const root=isolatedRuntimeRoot(path.dirname(fileURLToPath(import.meta.url)),path.dirname(fileURLToPath(import.meta.url)),8765);
const settings=(()=>{try{return JSON.parse(fs.readFileSync(path.join(root,"dashboard-config.json"),"utf8"))}catch{return {}}})();
const workbook=settings.nctWorkbookUrl||"";
const sheetName="年卡招考数据";
const columnMap={
  "订单Id":"orderId","用户Id":"userId","业务线":"businessLine","学员姓名":"userName","微信":"wechatNickName","已用课时":"usedTime","总课时":"totalTime","订单状态":"orderStatusStr","下单时间":"placedAt","订单来源":"orderSourceStr","订单类型":"orderTypeStr","优惠金额":"totalDiscount","实付金额":"actualPayment","付款方式":"payMethodStr","支付渠道":"payPlatformStr","商品指导价":"guidePrice","开单人":"creatorName","开单人组织架构":"creatorOrganization","开单人在职状态":"creatorStatusStr","是否售后":"afterSale","售后类型":"afterSaleType","补差金额":"differenceAmount","应付金额":"total","商品名称":"spuName","商品编码":"spuNumber","规格名称":"skuName","规格编码":"skuNumber","支付流水号":"payNo","支付状态":"payStatusStr","付款时间":"paidAt","归属人":"ownerName","归属人在职状态":"ownerState","业绩归属班期":"ownerTermStr","归属类型":"ownerTypeStr","分班状态":"classAssignStatusStr","渠道":"lbkChannel","订单认领状态":"ownerStatusStr","项目链接名称":"lbkOfficialPage","电销跟进人":"counselorName","电销组织架构":"counselorOrganization","电销在职状态":"counselorStatusStr"
};
const defaultHeaders=["订单Id","用户Id","学员姓名","订单状态","下单时间","商品名称","商品编码","规格名称","规格编码","实付金额","支付状态","付款时间","归属人","业绩归属班期","是否售后"];
const credentialsFiles=[process.env.CODEMAO_SCHOLARSHIP_CREDENTIALS_FILE,"C:/Users/user/Desktop/Documents/编程猫管理skill/codemao-student-profile-extracted/codemao-course-data/sync.py"].filter(Boolean);
const clean=v=>String(v??"").replace(/\s+/g," ").trim();
const csvEscape=v=>/[",\r\n]/.test(String(v??""))?`"${String(v??"").replace(/"/g,'""')}"`:String(v??"");
const matrixToCsv=m=>m.map(r=>r.map(csvEscape).join(",")).join("\r\n");
function columnLetter(number){let out="";for(let n=number;n>0;n=Math.floor((n-1)/26))out=String.fromCharCode(65+(n-1)%26)+out;return out}
function rowsFrom(value){if(Array.isArray(value)&&(!value.length||Array.isArray(value[0])))return value;if(!value||typeof value!=="object")return null;for(const key of ["values","data","rows","displayValues"]){if(Array.isArray(value[key])&&(!value[key].length||Array.isArray(value[key][0])))return value[key]}for(const child of Object.values(value)){const rows=rowsFrom(child);if(rows)return rows}return null}
function normalizeDateTime(value){
  const raw=clean(value);if(!raw)return "";
  const date=/^\d{10,13}$/.test(raw)?new Date(Number(raw)<1e11?Number(raw)*1000:Number(raw)):new Date(raw);
  if(Number.isNaN(date.getTime()))return raw;
  const parts=Object.fromEntries(new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Shanghai",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(date).filter(x=>x.type!=="literal").map(x=>[x.type,x.value]));
  return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second}`;
}
function displayValue(row,header,source){
  if(header==="下单时间")return normalizeDateTime(row.placedAt);
  if(header==="付款时间")return normalizeDateTime(row.paidAt);
  if(header==="业务线"){
    const readable=[row.businessLineStr,row.businessLineName,row.businessName].map(clean).find(Boolean);if(readable)return readable;
    const raw=clean(row.businessLine),mapped=clean(source?.lookups?.businessLine?.[raw]);return mapped||raw;
  }
  if(header==="是否售后"){
    const readable=clean(row.afterSaleStr||row.afterSaleName);if(readable)return readable;
    const raw=clean(row.afterSale);return raw==="1"?"是":raw==="0"?"否":raw;
  }
  return row[columnMap[header]||header]??"";
}
function credentials(){if(settings.dingtalkConnectionUrl)return {url:settings.dingtalkConnectionUrl,token:settings.dingtalkAccessKey||""};const file=credentialsFiles.find(fs.existsSync);if(!file)throw new Error("DINGTALK_MCP_CONFIG_NOT_FOUND");const text=fs.readFileSync(file,"utf8"),url=text.match(/MCP_URL\s*=\s*["']([^"']+)["']/)?.[1],token=text.match(/ACCESS_TOKEN\s*=\s*["']([^"']+)["']/)?.[1];if(!url)throw new Error("DINGTALK_MCP_CONFIG_INVALID");return {url,token:token||""}}
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function networkError(error,url,name,attempts){const cause=error?.cause;let host="钉钉连接";try{host=new URL(url).host||host}catch{}const reason=[error?.message,cause?.code,cause?.message].filter(Boolean).join(" / ");return new Error(`DINGTALK_NETWORK_FAILED:${host}:${name}:已重试${attempts}次:${reason||"网络连接失败"}`)}
async function mcp(name,args,timeoutMs=180000){const {url,token}=credentials(),attempts=4;for(let attempt=1;attempt<=attempts;attempt++){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);try{const headers={"content-type":"application/json",accept:"application/json"};if(token)headers.authorization=`Bearer ${token}`;const response=await fetch(url,{method:"POST",headers,body:JSON.stringify({jsonrpc:"2.0",method:"tools/call",params:{name,arguments:args},id:1}),signal:controller.signal});if(!response.ok){const error=new Error(`DINGTALK_MCP_HTTP_${response.status}`);error.transient=response.status===408||response.status===429||response.status>=500;throw error}const envelope=await response.json();if(envelope.error)throw new Error(`DINGTALK_MCP_ERROR:${JSON.stringify(envelope.error)}`);const text=envelope.result?.content?.find(x=>x.type==="text")?.text,result=text?JSON.parse(text):envelope.result;if(result?.success===false)throw new Error(`DINGTALK_TOOL_ERROR:${result.errorMsg||JSON.stringify(result)}`);return result}catch(error){const transient=error?.transient||error?.name==="AbortError"||error instanceof TypeError||["ECONNRESET","ECONNREFUSED","ETIMEDOUT","ENOTFOUND","EAI_AGAIN","UND_ERR_CONNECT_TIMEOUT","UND_ERR_SOCKET"].includes(error?.cause?.code);if(!transient)throw error;if(attempt===attempts)throw networkError(error,url,name,attempts);await wait([700,1600,3200][attempt-1]||3200)}finally{clearTimeout(timer)}}}
function normalizeDate(value){if(typeof value==="number"||/^\d{10,13}$/.test(clean(value))){const n=Number(value),d=new Date(n<1e11?n*1000:n);if(!Number.isNaN(d.getTime()))return d.toLocaleDateString("sv-SE",{timeZone:"Asia/Shanghai"})}const m=clean(value).replace(/\//g,"-").match(/^(\d{4}-\d{1,2}-\d{1,2})/);return m?m[1].split("-").map((x,i)=>i?x.padStart(2,"0"):x).join("-"):""}
async function resolveSheet(){const listing=await mcp("get_all_sheets",{nodeId:workbook}),sheets=Array.isArray(listing)?listing:(listing?.sheets||listing?.data?.sheets||[]),sheet=sheets.find(x=>clean(x?.name)===sheetName);if(!sheet)throw new Error(`DINGTALK_NCT_SHEET_NOT_FOUND:${sheetName}`);return sheet.sheetId||sheet.name}
async function main(){if(!workbook)throw new Error("请先在配置面板填写等考招考数据钉钉文档链接");const input=process.argv[2];if(!input||!fs.existsSync(input))throw new Error("NCT_INPUT_FILE_NOT_FOUND");const source=JSON.parse(fs.readFileSync(input,"utf8").replace(/^\uFEFF/,"")),rows=Array.isArray(source.rows)?source.rows:[],filters=source.filters||{};if(!rows.length)throw new Error("NCT_SOURCE_EMPTY");if(Number(source.rowcount||rows.length)!==rows.length)throw new Error(`NCT_SOURCE_COUNT_MISMATCH:${rows.length}/${source.rowcount}`);for(const row of rows){const paid=normalizeDate(row.paidAt);if(!paid||paid<filters.startDate||paid>filters.endDate)throw new Error(`NCT_FILTER_MISMATCH:付款时间:${row.paidAt}`);if(filters.orderStatus!=="全部"&&clean(row.orderStatusStr)!==clean(filters.orderStatus))throw new Error(`NCT_FILTER_MISMATCH:订单状态:${row.orderStatusStr}`);if(clean(row.spuName)!==clean(filters.productName))throw new Error(`NCT_FILTER_MISMATCH:商品名称:${row.spuName}`)}const sheetId=await resolveSheet(),headerResult=await mcp("get_range",{nodeId:workbook,sheetId,range:"A1:AZ1"}),existing=(rowsFrom(headerResult)?.[0]||[]).map(clean),headers=existing.filter(Boolean).length?existing.filter(Boolean):defaultHeaders;const unknown=headers.filter(h=>!columnMap[h]&&!Object.prototype.hasOwnProperty.call(rows[0],h));if(unknown.length)throw new Error(`NCT_TARGET_HEADER_UNSUPPORTED:${unknown.join("|")}`);const values=rows.map(row=>headers.map(h=>displayValue(row,h,source))),matrix=[headers,...values],lastColumn=columnLetter(headers.length),before=await mcp("get_sheet",{nodeId:workbook,sheetId}),previousLast=Number(before.nonEmptyRange?.lastRow||(Number(before.lastNonEmptyRow)+1)||1);for(let start=0;start<matrix.length;start+=500){const chunk=matrix.slice(start,start+500);await mcp("set_range_from_csv",{nodeId:workbook,sheetId,startCell:`A${start+1}`,csv:matrixToCsv(chunk),allowOverwrite:true})}const newLast=matrix.length;if(previousLast>newLast)await mcp("clear_range",{nodeId:workbook,sheetId,range:`A${newLast+1}:${lastColumn}${previousLast}`,type:"content"});const verify=rowsFrom(await mcp("get_range",{nodeId:workbook,sheetId,range:`A1:${lastColumn}${Math.min(newLast,2)}`}))||[];if(JSON.stringify((verify[0]||[]).map(clean))!==JSON.stringify(headers))throw new Error("NCT_VERIFY_HEADER_MISMATCH");if(verify.length<2)throw new Error("NCT_VERIFY_FIRST_ROW_MISSING");console.log(`NCT_CRM_OK rows=${rows.length} columns=${Object.keys(rows[0]).length}`);console.log(`NCT_SYNC_OK rows=${values.length} sheet=${sheetName}`)}
main().catch(error=>{console.error(String(error?.message||error));process.exitCode=1});
